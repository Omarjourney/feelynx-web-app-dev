export { FeelynxLogo as default } from './FeelynxLogo';
export { FeelynxLogo } from './FeelynxLogo';
export type { FeelynxLogoProps as IvibesLogoProps } from './FeelynxLogo';
