declare module 'node-cron' {
  const mod: any;
  export default mod;
}
