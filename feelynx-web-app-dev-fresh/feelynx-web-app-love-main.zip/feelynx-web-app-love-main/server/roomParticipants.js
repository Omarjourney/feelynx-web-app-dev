export const roomParticipants = {};
