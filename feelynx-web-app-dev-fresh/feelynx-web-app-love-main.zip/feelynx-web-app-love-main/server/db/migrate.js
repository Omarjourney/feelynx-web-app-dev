import { pool } from './index.js';
async function migrate() {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query(`CREATE TABLE IF NOT EXISTS users (
      id SERIAL PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL
    )`);
    await client.query(`CREATE TABLE IF NOT EXISTS posts (
      id SERIAL PRIMARY KEY,
      user_id INTEGER REFERENCES users(id),
      content TEXT NOT NULL
    )`);
    await client.query(`CREATE TABLE IF NOT EXISTS payments (
      id SERIAL PRIMARY KEY,
      user_id INTEGER REFERENCES users(id),
      amount NUMERIC NOT NULL,
      created_at TIMESTAMP DEFAULT NOW()
    )`);
    await client.query(`CREATE TABLE IF NOT EXISTS creators (
      id SERIAL PRIMARY KEY,
      created_at TIMESTAMP DEFAULT NOW(),
      last_online TIMESTAMP
    )`);
    await client.query(`CREATE TABLE IF NOT EXISTS payout_accounts (
      id SERIAL PRIMARY KEY,
      creator_id INTEGER REFERENCES creators(id),
      stripe_account_id TEXT NOT NULL,
      status TEXT NOT NULL
    )`);
    await client.query(`CREATE TABLE IF NOT EXISTS payouts (
      id SERIAL PRIMARY KEY,
      creator_id INTEGER REFERENCES creators(id),
      amount NUMERIC NOT NULL,
      status TEXT NOT NULL,
      initiated_at TIMESTAMP DEFAULT NOW(),
      processed_at TIMESTAMP
    )`);
    await client.query('COMMIT');
    console.log('Migration complete');
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('Migration failed', err);
  } finally {
    client.release();
  }
}
migrate().then(() => pool.end());
